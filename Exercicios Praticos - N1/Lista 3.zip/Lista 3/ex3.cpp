/*
3) Construa um programa que declare uma matriz 5 x 5. Preencha com 1
a diagonal principal e com 0 os demais elementos. Como resultado,
escreva a matriz obtida.
*/

#include<iostream>
#define N 5
using namespace std;

int main(){
    int mat[N][N];
    int i, j;

    for (i=0; i<N; i++){
        for(j=0; j<N; j++){
            if(i==j){
                mat[i][j]=1;
            }else{
                mat[i][j]=0;
            }
        }
    }

    for(i=0; i<N; i++){
        for(j=0; j<N; j++){
            cout << mat[i][j];
        }
    }
}