/*
1) Construa um programa que leia uma matriz de tamanho 5 x 5 e escreva a localização (linha, coluna) do maior valor encontrado na matriz.
*/
#include<iostream>
using namespace std;

int main(){
    int  mat[5][5];
    int maior=-999, linha, coluna, i, j;
    
    cout << "Matriz 5X5\n";
    for(i=0;i<5;i++){
        for(j=0;j<5;j++){
            cout << "Digite um numero: ";
            cin >> mat[i][j];
        }
    }

    maior = mat[1][1];
    for (i=0;i<5;i++){
        for (j=0;j<5;j++){
            if(mat[i][j]> maior) {
            maior = mat[i][j];
            linha = i;
            coluna = j;
            }
        }
    }
  cout << "O maior valor é o: "<<maior;
  cout << ", localizado na linha "<<linha;
  cout << " e coluna "<<coluna;
    
}