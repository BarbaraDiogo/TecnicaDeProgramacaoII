/*
3) Construa um programa que leia duas matrizes 3 x 3. Crie uma terceira
matriz a partir dos maiores elementos das matrizes lidas.
*/

#include<iostream>
#define N 3
using namespace std;

int main (){
    setlocale(LC_ALL,"Portuguese_Brazil");
    int mat1[N][N], mat2[N][N], mat3[N][N], i, j;
    
    for (i=0;i<N;i++){
        for (j=0;j<N;j++){
            cout << "Digite o valor de posição "<<i "X" <<j<<": ");
            cin << mat1[i][j];
        }
    }

     for (i=0;i<t;i++){
        for (j=0;j<t;j++){
            if (mat1[i][j] > mat2[i][j]){
                mat3[i][j] = mat1[i][j];
            }
            else{
                mat3[i][j] = mat2[i][j];
            }
        }
    }

    for (i=0;i<t;i++){
        for (j=0;j<t;j++){
            cout << mat3[i][j];
        }
        cout << "\n";
    }
}