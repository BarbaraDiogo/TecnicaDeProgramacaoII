/*
2) Faça um programa que leia uma matriz 3 x 3 e escreva:
    a) Soma dos elementos da diagonal principal;
    b) O maior elemento da diagonal secundária;
*/

#include<iostream>
#define N 3

using namespace std;
int main(){
    int  mat[N][N];
    int i, j, soma=0, maior=0;
    
    cout << "Matriz 3X3:\n" <<endl;
    for(i=0;i<N;i++){
        for(j=0;j<N;j++){
            cout << "Digite a linha "<<i<<" e a coluna "<<j<<": ";
            cin >> mat[i][j];
        }
    }

    i=0;
    while(i<N){
        if(mat[i][i]>maior){
            maior = mat[i][i];
        }

        soma += mat[i][i];
        i++;
    }
        cout << "Maior valor na diagonal: " << maior << ". \nSoma de elementos em diagonal: " << soma << endl << endl;

}