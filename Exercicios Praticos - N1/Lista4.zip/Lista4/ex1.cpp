/*
1) Construir duas matrizes 3X3. Crie uma terceira matriz a partir dos maiores elementos das matrizes lidas
*/

#include<iostream>
#define N 2
using namespace std;

void preencher (int mat1[N][N]){
    int i,j;
    for (i=0;i<N;i++)
    {
        for (j=0;j<N;j++)
        {
            cout << "Digite o valor de posição "<<i<<"x"<<j<<": ";
            cin >> mat1[i][j];
        }
    }
}

void ler (int mat1[N][N], int mat2[N][N], int mat3[N][N]){
    int i,j;
    for (i=0;i<N;i++)
    {
        for (j=0;j<N;j++)
        {
            if (mat1[i][j] > mat2[i][j]){
                mat3[i][j] = mat1[i][j];

            }else{
                mat3[i][j] = mat2[i][j];
            }
        }
    }
}

void mostrar (int mat3[N][N]){
    int i, j;
    for (i=0;i<N;i++){
        for (j=0;j<N;j++)
        {
            cout << mat3[i][j];
        }
        cout << "\n";
    }
}

int main(){
    int mat1[N][N], mat2[N][N], mat3[N][N];
    preencher(mat1);
    preencher(mat2);
    ler(mat1, mat2, mat3);
    mostrar(mat3);
}