/*
2) Faça um programa que preencha uma matriz 7X7 de numeros inteiros e crie dois vetores com sete posições cada um que contenham, respectivamente, o maior elemento de cada uma das linhas e o menor elemento de cada uma das colunas. Escreva a matriz e os dois vetores gerados.
*/
#include<iostream>
#define N 2
using namespace std;

int main(){
int mat[N][N];
int vet[N];
int i, j;
int menor = 0;
int maior = 0;

for (i = 0; i < N; i++){
    for (j = 0; j < N; j++){
        cout << "Digite o valor da posicao "<<i<< "X"<<j<<": ";
        cin >> mat[i][j];
    }
}
    cout << "\n\n\n";
    cout << "### Menores valores de cada coluna ### \n\n\n";
    for (j = 0; j < N; j++){
        for (i = 0; i < N; i++){
            if (mat [i][j] < menor){
                menor = mat [i] [j];
            }
        }
        vet [j] = menor;
    }
for (i = 0; i < N; i++){
    cout <<vet[i];
}

   cout << "\n\n\n";
    cout << "### Maiores valores de cada linha #### \n\n\n";
    for (j = 0; j < N; j++){
        for (i = 0; i < N; i++){
            if (mat [i][j] > maior){
                maior = mat [i] [j];
            }
        }
        vet [i] = maior;
    }
for (i = 0; i < N; i++){
    cout <<vet[j];
}

    cout <<"\n\n\n";
}