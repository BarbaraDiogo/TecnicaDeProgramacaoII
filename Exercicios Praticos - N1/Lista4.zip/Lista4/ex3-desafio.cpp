/*
3) Elabore um programa que preencha uma matriz 4X4 com numeros inteiros e verifique se essa matriz forma o chamado quadrado magico. Um quadrado magico é formado quando a soma dos elementos de cada linha é igual a soma dos elementos de cada coluna dessa linha, é igual à soma dos elementos da diagonal principal e, também, é igual à soma dos elementos da diagonal secundaria.
*/