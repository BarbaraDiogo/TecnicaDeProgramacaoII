//Barbara Diogo 2063853
//Ex.1

#include<iostream>
using std::cerr;
using std::cin;
using std::cout;
using std::endl;
using std::ios;
#include<fstream>
using std::ofstream;

int main(){

	ofstream Alunos_CC("clients.dat", ios::out);
	
	cout << "Informe numero de matricula, nome e e-mail" << endl;

	int matricula;
	char name[30];
	char email[200];

while(cin >> matricula >> name >> email){
	Alunos_CC << matricula << ' ' << name << ' ' << email << endl;
}

	return 0;
	
}